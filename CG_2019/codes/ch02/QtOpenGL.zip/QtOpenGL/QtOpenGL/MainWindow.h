#pragma once

#include "gltools.h"
#include <QtWidgets/QOpenGLWidget>
#include "ui_MainWindow.h"

class MainWindow : public QOpenGLWidget
{
	Q_OBJECT

public:
	MainWindow(QWidget *parent = Q_NULLPTR);
	~MainWindow();

protected:
	void initializeGL() override;
	void paintGL() override;
	void resizeGL(int w, int h) override;

private:
	Ui::MainWindowClass ui;
};
