#include "MainWindow.h"

MainWindow::MainWindow(QWidget *parent)
	: QOpenGLWidget(parent)
{
	ui.setupUi(this);
}

MainWindow::~MainWindow()
{

}

void MainWindow::initializeGL()
{
	// initialize GLEW library
	glewExperimental = true;
	glewInit();

	// set the background color
	glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
}

void MainWindow::resizeGL(int w, int h)
{
	// set the viewport
	glViewport(0, 0, w, h);
}

void MainWindow::paintGL()
{
	// render scenes
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_POLYGON);
	    glVertex2d(-0.5, -0.5);
		glVertex2d(-0.5, 0.5);
		glVertex2d(0.5, 0.5);
		glVertex2d(0.5, -0.5);
	glEnd();
	glFlush();
}
