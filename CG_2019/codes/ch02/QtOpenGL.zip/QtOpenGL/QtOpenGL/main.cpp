#include "MainWindow.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	MainWindow w;

	// setup OpenGL format
	QSurfaceFormat format;
	format.setVersion(4, 6);
	format.setProfile(QSurfaceFormat::CompatibilityProfile);
	format.setSamples(8);
	w.setFormat(format); // must be called before the widget or its parent window gets shown

	w.show();
	return a.exec();

}
