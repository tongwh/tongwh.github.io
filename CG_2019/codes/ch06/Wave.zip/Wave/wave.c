/* sets up flat mesh */
/* sets up elapsed time parameter for use by shaders */
/* vertex shader varies height of mesh sinusoidally */
/* uses a pass through fragment shader */

#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GL/glut.h>

#define N 64
const GLdouble nearVal     = 1.0; /* near distance */
const GLdouble farVal      = 20.0; /* far distance */
GLuint         program     = 0; /* program object id */
GLint          timeParam;
GLchar *ebuffer; /* buffer for error messages */
GLsizei elength; /* length of error message */
GLfloat data[N][N]; /* array of data heights */


/* shader reader */
/* creates null terminated string from file */
static GLboolean readShaderSource(GLuint shader, const char* shaderFile)
{
	FILE *fp;
	GLubyte *buf;
	int length;
	GLboolean ret = GL_TRUE;
	
	if (!(fp = fopen(shaderFile,"rb")))
	{
		return GL_FALSE;
	}
	
	fseek(fp, 0, SEEK_END);
	length = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	
	buf = (char*) malloc((length + 1) * sizeof(char));
	fread(buf, 1, length, fp);
	buf[length] = '\0';				// make it a regular C string so str* functions work
	
	glShaderSource(shader, 1, (const char**)&buf, &length);
	
	if (glGetError() != 0)
	{
		ret = GL_FALSE;
	}
	
	fclose(fp);
	
	free(buf);
	return ret;
}

/* GLSL initialization */

static GLboolean initShader(const GLchar* vShaderFile, const GLchar* fShaderFile)
{
	GLchar *pInfoLog = NULL;
	GLint compiled  = GL_FALSE;
	GLint linked    = GL_FALSE;
	GLint maxLength, length;
	GLuint ProgramObject;
	GLuint VertexShaderObject;
	GLuint FragmentShaderObject;

	/* create shader and program objects */
	ProgramObject = glCreateProgram();

	VertexShaderObject = glCreateShader(GL_VERTEX_SHADER);
	readShaderSource(VertexShaderObject, vShaderFile);

	FragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
	readShaderSource(FragmentShaderObject, fShaderFile);

	/* attach shader objects */
	glAttachShader(ProgramObject, VertexShaderObject);
	glAttachShader(ProgramObject, FragmentShaderObject);
	
	/* compile the vertex shader and fragment shader */
	glCompileShader(VertexShaderObject);
	glGetShaderiv(VertexShaderObject, GL_COMPILE_STATUS, &compiled);
	if (compiled == GL_TRUE)
	{
		printf("Vertex shader compiled succeeded.\n");
	}
	else
	{
		glGetShaderiv(VertexShaderObject, GL_INFO_LOG_LENGTH, &maxLength);

		pInfoLog = (GLchar *) malloc(maxLength * sizeof(GLchar));
		glGetShaderInfoLog(VertexShaderObject, maxLength, &length, pInfoLog);
		printf("Vertex shader compiled failed: %s\n\n", pInfoLog);
		free(pInfoLog);

		return GL_FALSE;
	}

	glCompileShader(FragmentShaderObject);
	glGetShaderiv(FragmentShaderObject, GL_COMPILE_STATUS, &compiled);
	if (compiled == GL_TRUE)
	{
		printf("Fragment shader compiled succeeded.\n");
	}
	else
	{
		glGetShaderiv(FragmentShaderObject, GL_INFO_LOG_LENGTH, &maxLength);

		pInfoLog = (GLchar *) malloc(maxLength * sizeof(GLchar));;
		glGetShaderInfoLog(FragmentShaderObject, maxLength, &length, pInfoLog);
		printf("Fragment shader compiled failed: %s\n\n", pInfoLog);
		free(pInfoLog);

		return GL_FALSE;
	}

	/*  link the program */
	glLinkProgram(ProgramObject);
	glGetProgramiv(ProgramObject, GL_LINK_STATUS, &compiled);
	if (compiled == GL_TRUE)
	{
		printf("Program linked succeeded.\n\n");
	}
	if (compiled == GL_FALSE)
	{
		glGetProgramiv(ProgramObject, GL_INFO_LOG_LENGTH, &maxLength);
		
		pInfoLog = (GLchar *) malloc(maxLength * sizeof(GLchar));
		glGetProgramInfoLog(ProgramObject, maxLength, &length, pInfoLog);
		printf("Program linked failed: %s\n\n", pInfoLog);
		free(pInfoLog);
		
		return GL_FALSE;
	}
	
	/* delete shader objects */
	glDeleteShader(VertexShaderObject);
	glDeleteShader(FragmentShaderObject);

    /* set up uniform parameter */
    timeParam = glGetUniformLocation(ProgramObject, "time");

	/* use program object */
	if (compiled == GL_TRUE) 
	{
		glUseProgram(ProgramObject);
		return GL_TRUE;
	}
	else
	{
		return GL_FALSE;
	}
}

/* standard OpenGL initialization */

static void init()
{
	GLenum err = glewInit();
	if (err != GLEW_OK)
	{
		printf("GLEW initialize error!\n");
		exit(-1);
	}
	
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glColor3f(0.0, 0.0, 0.0);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-0.75,0.75,-0.75,0.75,-5.5,5.5);
}

void mesh(void)
{
    int i,j;
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(2.0, 2.0, 2.0, 0.5, 0.0, 0.5, 0.0, 1.0, 0.0);
    for(i=0; i<N; i++) for(j=0; j<N;j++)
    {
       glColor3f(1.0, 1.0, 1.0);
       glBegin(GL_POLYGON);
          glVertex3f((float)i/N, data[i][j], (float)j/N);
          glVertex3f((float)i/N, data[i][j], (float)(j+1)/N);
          glVertex3f((float)(i+1)/N, data[i][j], (float)(j+1)/N);
          glVertex3f((float)(i+1)/N, data[i][j], (float)(j)/N);
       glEnd();  
       glColor3f(0.0, 0.0, 0.0);
       glBegin(GL_LINE_LOOP);
          glVertex3f((float)i/N, data[i][j], (float)j/N);
          glVertex3f((float)i/N, data[i][j], (float)(j+1)/N);
          glVertex3f((float)(i+1)/N, data[i][j], (float)(j+1)/N);
          glVertex3f((float)(i+1)/N, data[i][j], (float)(j)/N);
       glEnd();  
    }
}

static void draw(void)
{
    /* send elapsed time to shaders */
	float time = (GLfloat) glutGet(GLUT_ELAPSED_TIME);
	printf("time is: %f\n", time);

    glUniform1f(timeParam, (GLfloat)glutGet(GLUT_ELAPSED_TIME));
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    mesh();
    glutSwapBuffers();
}

static void reshape(int w, int h)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-0.75,0.75,-0.75,0.75,-5.5,5.5);

    glViewport(0, 0, w, h);
    glutPostRedisplay();
}

static void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 27:
    case 'Q':
    case 'q':
        exit(EXIT_SUCCESS);
        break;
    default:
        break;
    }
}

void idle(void)
{
	glutPostRedisplay();
}

int main(int argc, char** argv)
{
    int i,j;

    /* flat mesh */ 
    for(i=0;i<N;i++) for(j=0;j<N;j++) data[i][j]=0.0;

	glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
    glutInitWindowSize(512, 512);
    glutCreateWindow("Simple GLSL example");
    glutDisplayFunc(draw);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutIdleFunc(idle);

    init();
    initShader("vmesh.glsl", "fPassthrough.glsl");

    glutMainLoop();
}
