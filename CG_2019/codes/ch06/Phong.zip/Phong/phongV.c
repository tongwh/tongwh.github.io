/* display teapot with vertex and fragment shaders */
/* sets up elapsed time parameter for use by shaders */

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif
#pragma comment(lib, "glew32.lib")

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <GL/glew.h>
#include <GL/glut.h>

const GLdouble nearVal     = 1.0;
const GLdouble farVal      = 20.0;
const GLfloat  lightPos[4] = {3.0f, 3.0f, 3.0f, 1.0f};
GLuint         program     = 0;
GLint          timeParam;

/* shader reader */
/* creates null terminated string from file */

static GLboolean readShaderSource(GLuint shader, const char* shaderFile)
{
	FILE *fp;
	GLubyte *buf;
	int length;
	GLboolean ret = GL_TRUE;

	if (!(fp = fopen(shaderFile, "rb")))
	{
		return GL_FALSE;
	}

	fseek(fp, 0, SEEK_END);
	length = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	buf = (char*)malloc((length + 1) * sizeof(char));
	fread(buf, 1, length, fp);
	buf[length] = '\0';				// make it a regular C string so str* functions work

	glShaderSource(shader, 1, (const char**)&buf, &length);

	if (glGetError() != 0)
	{
		ret = GL_FALSE;
	}

	fclose(fp);

	free(buf);
	return ret;
}

/* GLSL initialization */

static GLboolean initShader(const GLchar* vShaderFile, const GLchar* fShaderFile)
{
	GLchar *pInfoLog = NULL;
	GLint compiled = GL_FALSE;
	GLint linked = GL_FALSE;
	GLint maxLength, length;
	GLuint ProgramObject;
	GLuint VertexShaderObject;
	GLuint FragmentShaderObject;

	/* create shader and program objects */
	ProgramObject = glCreateProgram();

	VertexShaderObject = glCreateShader(GL_VERTEX_SHADER);
	readShaderSource(VertexShaderObject, vShaderFile);

	FragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
	readShaderSource(FragmentShaderObject, fShaderFile);

	/* attach shader objects */
	glAttachShader(ProgramObject, VertexShaderObject);
	glAttachShader(ProgramObject, FragmentShaderObject);

	/* compile the vertex shader and fragment shader */
	glCompileShader(VertexShaderObject);
	glGetShaderiv(VertexShaderObject, GL_COMPILE_STATUS, &compiled);
	if (compiled == GL_TRUE)
	{
		printf("Vertex shader compiled succeeded.\n");
	}
	else
	{
		glGetShaderiv(VertexShaderObject, GL_INFO_LOG_LENGTH, &maxLength);

		pInfoLog = (GLchar *)malloc(maxLength * sizeof(GLchar));
		glGetShaderInfoLog(VertexShaderObject, maxLength, &length, pInfoLog);
		printf("Vertex shader compiled failed: %s\n\n", pInfoLog);
		free(pInfoLog);

		return GL_FALSE;
	}

	glCompileShader(FragmentShaderObject);
	glGetShaderiv(FragmentShaderObject, GL_COMPILE_STATUS, &compiled);
	if (compiled == GL_TRUE)
	{
		printf("Fragment shader compiled succeeded.\n");
	}
	else
	{
		glGetShaderiv(FragmentShaderObject, GL_INFO_LOG_LENGTH, &maxLength);

		pInfoLog = (GLchar *)malloc(maxLength * sizeof(GLchar));;
		glGetShaderInfoLog(FragmentShaderObject, maxLength, &length, pInfoLog);
		printf("Fragment shader compiled failed: %s\n\n", pInfoLog);
		free(pInfoLog);

		return GL_FALSE;
	}

	/*  link the program */
	glLinkProgram(ProgramObject);
	glGetProgramiv(ProgramObject, GL_LINK_STATUS, &compiled);
	if (compiled == GL_TRUE)
	{
		printf("Program linked succeeded.\n\n");
	}
	if (compiled == GL_FALSE)
	{
		glGetProgramiv(ProgramObject, GL_INFO_LOG_LENGTH, &maxLength);

		pInfoLog = (GLchar *)malloc(maxLength * sizeof(GLchar));
		glGetProgramInfoLog(ProgramObject, maxLength, &length, pInfoLog);
		printf("Program linked failed: %s\n\n", pInfoLog);
		free(pInfoLog);

		return GL_FALSE;
	}

	/* delete shader objects */
	glDeleteShader(VertexShaderObject);
	glDeleteShader(FragmentShaderObject);

	/* use program object */
	if (compiled == GL_TRUE)
	{
		glUseProgram(ProgramObject);
		return GL_TRUE;
	}
	else
	{
		return GL_FALSE;
	}
}

/* standard OpenGL initialization */

static void init()
{
    const float teapotColor[]     = {0.3f, 0.5f, 0.4f, 1.0f}; 
    const float teapotSpecular[]  = {0.8f, 0.8f, 0.8f, 1.0f};
    const float teapotShininess[] = {80.0f};

	GLenum err = glewInit();
	if (err != GLEW_OK)
	{
		printf("GLEW initialize error!\n");
		exit(-1);
	}

    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, teapotColor);
    glMaterialfv(GL_FRONT, GL_SPECULAR, teapotSpecular);
    glMaterialfv(GL_FRONT, GL_SHININESS, teapotShininess);

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double) glutGet(GLUT_WINDOW_WIDTH) / (double) glutGet(GLUT_WINDOW_HEIGHT), nearVal, farVal);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    glEnable(GL_LIGHTING); 
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);
}

static void draw(void)
{
    /* send elapsed time to shaders */
    glUniform1f(timeParam, glutGet(GLUT_ELAPSED_TIME));

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
    glTranslatef(0.0f, 0.0f, -5.0f);
    glutSolidTeapot(1.0);
    glPopMatrix();
    glutSwapBuffers();
}

static void reshape(int w, int h)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double) w / (double) h, nearVal, farVal);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glViewport(0, 0, w, h);

    glutPostRedisplay();
}

static void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 27:
    case 'Q':
    case 'q':
        exit(EXIT_SUCCESS);
        break;
    default:
        break;
    }
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(512, 512);
    glutCreateWindow("Simple GLSL example");
    glutDisplayFunc(draw);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);

    init();
    initShader("vPhong.glsl", "fPassthrough.glsl");

    glutMainLoop();
    return 0;
}
