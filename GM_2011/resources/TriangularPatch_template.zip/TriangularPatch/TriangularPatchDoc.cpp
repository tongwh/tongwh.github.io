// TriangularPatchDoc.cpp : implementation of the CTriangularPatchDoc class
//

#include "stdafx.h"
#include "TriangularPatch.h"

#include "TriangularPatchDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchDoc

IMPLEMENT_DYNCREATE(CTriangularPatchDoc, CDocument)

BEGIN_MESSAGE_MAP(CTriangularPatchDoc, CDocument)
	//{{AFX_MSG_MAP(CTriangularPatchDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchDoc construction/destruction

CTriangularPatchDoc::CTriangularPatchDoc()
{
	// TODO: add one-time construction code here

}

CTriangularPatchDoc::~CTriangularPatchDoc()
{
}

BOOL CTriangularPatchDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchDoc serialization

void CTriangularPatchDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchDoc diagnostics

#ifdef _DEBUG
void CTriangularPatchDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTriangularPatchDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchDoc commands
