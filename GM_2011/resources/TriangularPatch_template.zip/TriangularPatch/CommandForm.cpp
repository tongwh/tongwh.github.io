// CommandForm.cpp : implementation file
//

#include "stdafx.h"
#include "TriangularPatch.h"
#include "CommandForm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCommandForm

IMPLEMENT_DYNCREATE(CCommandForm, CFormView)

CCommandForm::CCommandForm()
	: CFormView(CCommandForm::IDD)
{
	//{{AFX_DATA_INIT(CCommandForm)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CCommandForm::~CCommandForm()
{
}

void CCommandForm::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCommandForm)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCommandForm, CFormView)
	//{{AFX_MSG_MAP(CCommandForm)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCommandForm diagnostics

#ifdef _DEBUG
void CCommandForm::AssertValid() const
{
	CFormView::AssertValid();
}

void CCommandForm::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCommandForm message handlers
