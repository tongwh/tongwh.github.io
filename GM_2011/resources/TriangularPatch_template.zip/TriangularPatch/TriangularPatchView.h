// TriangularPatchView.h : interface of the CTriangularPatchView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRIANGULARPATCHVIEW_H__DE443C96_C9D5_4C4B_AF88_74925CACC2EB__INCLUDED_)
#define AFX_TRIANGULARPATCHVIEW_H__DE443C96_C9D5_4C4B_AF88_74925CACC2EB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <math.h>
#include <windows.h>
#include <gl/glu.h>
#include <gl/glut.h>

class CTriangularPatchDoc;

class CTriangularPatchView : public CView
{
protected: // create from serialization only
	CTriangularPatchView();
	DECLARE_DYNCREATE(CTriangularPatchView)

// Attributes
public:
	CTriangularPatchDoc* GetDocument();

	// OpenGL Windows specfication
	HDC m_hDC;			// Device Context
	HGLRC m_hGLRC;		// Rendering Context
	CPalette m_cGLLP;	// Logical Palette
	
	// OpenGL view parameters
	CPoint m_ptPrev;
	GLfloat m_vPrevVec[3], m_vCurVec[3];
	GLfloat m_fViewingDistance, m_fFovy;
	GLfloat m_fNearFactor, m_fFarFactor;
	GLfloat m_fZoomScale, m_fPanOffsetX, m_fPanOffsetY;
	bool m_bIsTracking;
	GLfloat m_vAxis[3]; 
	GLfloat m_fTrackingAngle;
	GLfloat m_mxTransform[4][4];
	GLint m_vViewport[4];

	// Mouse status
	enum ManipulMode 
	{
		None=0, 
		Trackball, 
		Zooming, 
		Panning
	};
	ManipulMode m_eManipulationMode;
	BOOL m_isDrawAnimation;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTriangularPatchView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTriangularPatchView();
	void InitializePalette(void);
	
	// OpenGL relation function
	void GLSetupDef(void *pData);
	void GLPtTo3DVec(CPoint point, GLfloat *pVec);
	void GLUpdate(void);
	void GLSetupFrustum(void);
	void GLSetupTransform(void);
	void GLRenderScene(void *pData);

private:

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTriangularPatchView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TriangularPatchView.cpp
inline CTriangularPatchDoc* CTriangularPatchView::GetDocument()
   { return (CTriangularPatchDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRIANGULARPATCHVIEW_H__DE443C96_C9D5_4C4B_AF88_74925CACC2EB__INCLUDED_)
