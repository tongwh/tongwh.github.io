#if !defined(AFX_COMMANDFORM_H__1BAD996E_3814_4795_9411_4DCC2461EDAD__INCLUDED_)
#define AFX_COMMANDFORM_H__1BAD996E_3814_4795_9411_4DCC2461EDAD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CommandForm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCommandForm form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CCommandForm : public CFormView
{
protected:
	CCommandForm();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CCommandForm)

// Form Data
public:
	//{{AFX_DATA(CCommandForm)
	enum { IDD = IDD_COMMANDFORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCommandForm)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CCommandForm();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CCommandForm)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMMANDFORM_H__1BAD996E_3814_4795_9411_4DCC2461EDAD__INCLUDED_)
