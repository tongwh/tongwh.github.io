// TriangularPatch.h : main header file for the TRIANGULARPATCH application
//

#if !defined(AFX_TRIANGULARPATCH_H__2708F198_3C2E_40EE_8E95_F9D1655A6E81__INCLUDED_)
#define AFX_TRIANGULARPATCH_H__2708F198_3C2E_40EE_8E95_F9D1655A6E81__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchApp:
// See TriangularPatch.cpp for the implementation of this class
//

class CTriangularPatchApp : public CWinApp
{
public:
	CTriangularPatchApp();

private:
	void CreateConsole();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTriangularPatchApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CTriangularPatchApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRIANGULARPATCH_H__2708F198_3C2E_40EE_8E95_F9D1655A6E81__INCLUDED_)
