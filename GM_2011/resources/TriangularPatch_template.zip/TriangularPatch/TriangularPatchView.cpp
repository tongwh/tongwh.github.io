// TriangularPatchView.cpp : implementation of the CTriangularPatchView class
//

#include "stdafx.h"
#include "TriangularPatch.h"

#include "TriangularPatchDoc.h"
#include "TriangularPatchView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const double PI = 3.1415926;

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchView

IMPLEMENT_DYNCREATE(CTriangularPatchView, CView)

BEGIN_MESSAGE_MAP(CTriangularPatchView, CView)
	//{{AFX_MSG_MAP(CTriangularPatchView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_KEYDOWN()
	ON_WM_ERASEBKGND()
	ON_WM_MOUSEWHEEL()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchView construction/destruction

CTriangularPatchView::CTriangularPatchView()
{
	// TODO: add construction code here
	// OpenGL windows specification
	m_hDC = 0;
	m_hGLRC = NULL;
	
	// OpenGL view parameter
	m_vPrevVec[0] = m_vPrevVec[1] = m_vPrevVec[2] = 0.0f;
	m_vCurVec[0] = m_vCurVec[1] = m_vCurVec[2] = 0.0f;

	GLfloat SCENE_SCALE = 10.0f;
	m_fViewingDistance = SCENE_SCALE * 2.0f;
	m_fFovy = 30.0f; m_fNearFactor = 0.1f; m_fFarFactor = 10.0f;
	
	m_fZoomScale = m_fViewingDistance * m_fNearFactor 
				* (float)tan(m_fFovy * PI / 360.0);
	m_fPanOffsetX = 0.0f; m_fPanOffsetY = 0.0f;

	// default view transform
	m_mxTransform[0][0] = 0.544677f; m_mxTransform[0][1] = -0.362249f;
	m_mxTransform[0][2] = 0.756375f; m_mxTransform[0][3] = 0.0f;
    m_mxTransform[1][0] = 0.838644f; m_mxTransform[1][1] = 0.233635f;
	m_mxTransform[1][2] = -0.492026f; m_mxTransform[1][3] = 0.0f;
    m_mxTransform[2][0] = 0.001520f; m_mxTransform[2][1] = 0.902324f;
	m_mxTransform[2][2] = 0.431054f; m_mxTransform[2][3] = 0.0f;
    m_mxTransform[3][0] = 0.0f; m_mxTransform[3][1] = 0.0f;
	m_mxTransform[3][2] = 0.0f; m_mxTransform[3][3] = 1.0f;

	m_bIsTracking = false;
	m_eManipulationMode = None;

}

CTriangularPatchView::~CTriangularPatchView()
{
	// TODO: add construction code here

}

BOOL CTriangularPatchView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchView drawing

void CTriangularPatchView::OnDraw(CDC* pDC)
{
	// TODO: add draw code for native data here
	CTriangularPatchDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	wglMakeCurrent(m_hDC, m_hGLRC);
	
	// Draw the scene
	GLRenderScene(pDoc);
	
	// Double buffer
	SwapBuffers(m_hDC);
	
	wglMakeCurrent(m_hDC, NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchView printing

BOOL CTriangularPatchView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTriangularPatchView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTriangularPatchView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchView diagnostics

#ifdef _DEBUG
void CTriangularPatchView::AssertValid() const
{
	CView::AssertValid();
}

void CTriangularPatchView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTriangularPatchDoc* CTriangularPatchView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTriangularPatchDoc)));
	return (CTriangularPatchDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMeshAnalysisView Implementation

/////////////////////////////////////////////////////////////////////////////
// CTriangularPatchView message handlers

/////////////////////////////////////////////////////////////////////////////
// InitializePalette: Initialize Palette if need, called by OnCreate
void CTriangularPatchView::InitializePalette(void)
{
	PIXELFORMATDESCRIPTOR pfd;	// Pixel Format Descriptor
	LOGPALETTE *pPal;			// Pointer to memory for logical palette
	int nPixelFormat;			// Pixel format index
	int nColors;				// Number of entries in palette
	int i;						// Counting variable
	BYTE RedRange,GreenRange,BlueRange;
	// Range for each color entry (7,7,and 3)
	
	// Get the pixel format index and retrieve the pixel format description
	nPixelFormat = GetPixelFormat(m_hDC);
	DescribePixelFormat(m_hDC, nPixelFormat, sizeof(PIXELFORMATDESCRIPTOR), &pfd);
	
	// Does this pixel format require a palette?  If not, do not create a
	// palette and just return NULL
	if(!(pfd.dwFlags & PFD_NEED_PALETTE))
		return;
	
	// Number of entries in palette.  8 bits yeilds 256 entries
	nColors = 1 << pfd.cColorBits;	
	
	// Allocate space for a logical palette structure plus all the palette entries
	pPal = (LOGPALETTE*)malloc(sizeof(LOGPALETTE) +nColors*sizeof(PALETTEENTRY));
	
	// Fill in palette header 
	pPal->palVersion = 0x300;		// Windows 3.0
	pPal->palNumEntries = nColors; // table size
	
	// Build mask of all 1's.  This creates a number represented by having
	// the low order x bits set, where x = pfd.cRedBits, pfd.cGreenBits, and
	// pfd.cBlueBits.  
	RedRange = (1 << pfd.cRedBits) -1;
	GreenRange = (1 << pfd.cGreenBits) - 1;
	BlueRange = (1 << pfd.cBlueBits) -1;
	
	// Loop through all the palette entries
	for(i = 0; i < nColors; i++)
	{
		// Fill in the 8-bit equivalents for each component
		pPal->palPalEntry[i].peRed = (i >> pfd.cRedShift) & RedRange;
		pPal->palPalEntry[i].peRed = (unsigned char)(
			(double) pPal->palPalEntry[i].peRed * 255.0 / RedRange);
		
		pPal->palPalEntry[i].peGreen = (i >> pfd.cGreenShift) & GreenRange;
		pPal->palPalEntry[i].peGreen = (unsigned char)(
			(double)pPal->palPalEntry[i].peGreen * 255.0 / GreenRange);
		
		pPal->palPalEntry[i].peBlue = (i >> pfd.cBlueShift) & BlueRange;
		pPal->palPalEntry[i].peBlue = (unsigned char)(
			(double)pPal->palPalEntry[i].peBlue * 255.0 / BlueRange);
		
		pPal->palPalEntry[i].peFlags = (unsigned char) NULL;
	}
	
	// Create the palette
	m_cGLLP.CreatePalette(pPal);
	
	// Go ahead and select and realize the palette for this device context
	SelectPalette(m_hDC,(HPALETTE)m_cGLLP,FALSE);
	RealizePalette(m_hDC);
	
	// Free the memory used for the logical palette structure
	free(pPal);
	
}

/////////////////////////////////////////////////////////////////////////////
// GLSetupDef: Do any initialization of the rendering context here, such as
// setting background colors, setting up lighting, or performing 
// preliminary calculations.
void CTriangularPatchView::GLSetupDef(void *pData)
{
	// White background
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	
	// setting up lighting
	GLfloat light_position1[4] = {-52.0f, -16.0f, -50.0f, 0.0f};
	GLfloat light_position2[4] = {-26.0f, -48.0f, -50.0f, 0.0f};
	GLfloat light_position3[4] = { 16.0f, -52.0f, -50.0f, 0.0f};

	GLfloat direction1[3] = {52.0f, 16.0f, 50.0f};
	GLfloat direction2[3] = {26.0f, 48.0f, 50.0f};
	GLfloat direction3[3] = {-16.0f, 52.0f, 50.0f};

	GLfloat light_position4[4] = {52.0f, 16.0f, 50.0f, 0.0f};
	GLfloat light_position5[4] = {26.0f, 48.0f, 50.0f, 0.0f};
	GLfloat light_position6[4] = {-16.0f, 52.0f, 50.0f, 0.0f};

	GLfloat direction4[3] = {-52.0f, -16.0f, -50.0f};
	GLfloat direction5[3] = {-26.0f, -48.0f, -50.0f};
	GLfloat direction6[3] = {16.0f, -52.0f, -50.0f};

	GLfloat color1[4] = {1.0f, 0.0f, 0.0f, 1.0f};
	GLfloat color2[4] = {0.0f, 1.0f, 0.0f, 1.0f};
	GLfloat color3[4] = {0.0f, 0.0f, 1.0f, 1.0f};

	GLfloat color4[4] = {1.0f, 0.0f, 0.0f, 1.0f};
	GLfloat color5[4] = {0.0f, 1.0f, 0.0f, 1.0f};
	GLfloat color6[4] = {0.0f, 0.0f, 1.0f, 1.0f};
	
/**
	GLfloat color1[4] = {0.7f,0.7f,0.7f,0.7f};
	GLfloat color2[4] = {0.7f,0.7f,0.7f,0.7f};
	GLfloat color3[4] = {0.7f,0.7f,0.7f,0.7f};

	GLfloat color4[4] = {0.05f, 0.05f, 0.60f, 1.0f};
	GLfloat color5[4] = {0.60f, 0.05f, 0.05f, 1.0f};
	GLfloat color6[4] = {1.00f, 1.00f, 1.0f, 1.0f};  

	GLfloat color1[4] = {0.8f,0.3f,0.1f,1.2f};
	GLfloat color2[4] = {0.1f,0.8f,0.3f,1.2f};
	GLfloat color3[4] = {0.3f,0.1f,0.8f,1.2f};

	GLfloat color4[4] = {0.8f,0.3f,0.1f,1.2f};
	GLfloat color5[4] = {0.1f,0.8f,0.3f,1.2f};
	GLfloat color6[4] = {0.3f,0.1f,0.8f,1.2f};
/**/

	glLightfv(GL_LIGHT0, GL_POSITION, light_position1);
	glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, direction1);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, color1);
	glLightfv(GL_LIGHT0, GL_SPECULAR, color1);

	glLightfv(GL_LIGHT1, GL_POSITION, light_position2);
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, direction2);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, color2);
	glLightfv(GL_LIGHT1, GL_SPECULAR, color2);

	glLightfv(GL_LIGHT2, GL_POSITION, light_position3);
	glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, direction3);
	glLightfv(GL_LIGHT2, GL_DIFFUSE, color3);
	glLightfv(GL_LIGHT2, GL_SPECULAR, color3);

	glLightfv(GL_LIGHT3, GL_POSITION, light_position4);
	glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, direction4);
	glLightfv(GL_LIGHT3, GL_DIFFUSE, color4);
	glLightfv(GL_LIGHT3, GL_SPECULAR, color4);

	glLightfv(GL_LIGHT4, GL_POSITION, light_position5);
	glLightfv(GL_LIGHT4, GL_SPOT_DIRECTION, direction5);
	glLightfv(GL_LIGHT4, GL_DIFFUSE, color5);
	glLightfv(GL_LIGHT4, GL_SPECULAR, color5);

	glLightfv(GL_LIGHT5, GL_POSITION, light_position6);
	glLightfv(GL_LIGHT5, GL_SPOT_DIRECTION, direction6);
	glLightfv(GL_LIGHT5, GL_DIFFUSE, color6);
	glLightfv(GL_LIGHT5, GL_SPECULAR, color6);

	glEnable(GL_LIGHTING);

/**
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHT2);
/**/

	glEnable(GL_LIGHT3);
	glEnable(GL_LIGHT4);
	glEnable(GL_LIGHT5);

	// set material
	GLfloat ambient[4] = {0.3f, 0.3f, 0.3f, 0.5f};
	GLfloat material_ambient[4] = {0.0f, 0.0f, 0.0f, 0.0f};
	GLfloat material_diffuse[4] = {1.0f, 1.0f, 1.0f, 0.3f};
	GLfloat material_specular[4] = {0.5f, 0.5f, 0.5f, 0.5f};
	GLfloat material_shininess = 51.2f;

/**
	GLfloat ambient[4] = {0.3f, 0.3f, 0.3f, 0.5f};
	GLfloat material_ambient[] = {0.2, 0.2, 0.2, 1.0};
	GLfloat material_diffuse[] = {0.4, 0.4, 0.4, 1.0};
	GLfloat material_specular[] = {0.8, 0.8, 0.8, 1.0};
	GLfloat material_shininess = 128.0f;
/**/

	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, material_specular);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, material_diffuse);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, material_ambient);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, material_shininess);
	
	glDepthFunc(GL_LESS);
	glEnable(GL_DEPTH_TEST);

//	glCullFace(GL_BACK);
//	glEnable(GL_CULL_FACE);

	// Setting point, line, polygon draw mode
	glPointSize(1.0);
//	glPointSize(2.0);
//	glPointSize(10.0);
	glLineWidth(1.0);
	
//	glEnable(GL_POINT_SMOOTH);
//	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
//	glEnable(GL_LINE_SMOOTH);
//	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glEnable(GL_POLYGON_SMOOTH);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
	
//  Setting blend mode
//	glEnable(GL_BLEND);    
//  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
//  glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	
//  Clock wise wound polygons are front facing, this is reversed
//  because we are using triangle fans
	glFrontFace(GL_CCW);
//	glPolygonMode(GL_BACK, GL_LINE);
	
}


int CTriangularPatchView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	int nPixelFormat;						// Pixel format index
	HWND hWnd = GetSafeHwnd();				// Get the window's handle
	m_hDC = ::GetDC(hWnd);					// Get the Device context
	
	static PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),		// Size of this structure
			1,								// Version of this structure	
			PFD_DRAW_TO_WINDOW |			// Draw to Window (not to bitmap)
			PFD_SUPPORT_OPENGL |			// Support OpenGL calls in window
			PFD_DOUBLEBUFFER,				// Double buffered mode
			PFD_TYPE_RGBA,					// RGBA Color mode
			24,								// Want 24bit color 
			0,0,0,0,0,0,					// Not used to select mode
			0,0,							// Not used to select mode
			0,0,0,0,0,						// Not used to select mode
			32,								// Size of depth buffer
			0,								// Not used to select mode
			0,								// Not used to select mode
			PFD_MAIN_PLANE,					// Draw in main plane
			0,								// Not used to select mode
			0,0,0 };						// Not used to select mode
		
	// Choose a pixel format that best matches that described in pfd
	nPixelFormat = ChoosePixelFormat(m_hDC, &pfd);
		
	// Set the pixel format for the device context
	VERIFY(SetPixelFormat(m_hDC, nPixelFormat, &pfd));
		
	// Create the rendering context
	m_hGLRC = wglCreateContext(m_hDC);
		
	// Create the palette if needed
	InitializePalette();
		
	// Make the rendering context current, perform initialization, then deselect it
	VERIFY(wglMakeCurrent(m_hDC, m_hGLRC));
	GLSetupDef(m_hDC);
	wglMakeCurrent(NULL, NULL);
		
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// Handlers: OnDestroy
void CTriangularPatchView::OnDestroy() 
{
	// TODO: Add your message handler code here
	if(wglGetCurrentContext() != NULL)
		wglMakeCurrent(NULL,NULL);
	
	if(m_hGLRC != NULL)
	{
		wglDeleteContext(m_hGLRC);
		m_hGLRC = NULL;
	}
	
	KillTimer(1);
	
	CView::OnDestroy();	
	
}

void CTriangularPatchView::GLUpdate(void)
{
	// TODO: update OpenGL scene, called by CTMeshSplineDoc
	CTriangularPatchDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	// TODO: add draw code for native data here
    wglMakeCurrent(m_hDC, m_hGLRC);
	
    // Draw scene
    GLRenderScene(pDoc);
	
    // Double buffer
    SwapBuffers(m_hDC);
	
    wglMakeCurrent(m_hDC, NULL);
}

/////////////////////////////////////////////////////////////////////////////
// Handlers: OnSize
void CTriangularPatchView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	VERIFY(wglMakeCurrent(m_hDC,m_hGLRC));
	m_vViewport[0] = 0; m_vViewport[1] = 0;
	m_vViewport[2] = cx; m_vViewport[3] = cy;
	glViewport(m_vViewport[0], m_vViewport[1], m_vViewport[2], m_vViewport[3]);
	VERIFY(wglMakeCurrent(NULL,NULL));	
	
}

/////////////////////////////////////////////////////////////////////////////
// Handlers: OnLButtonDown
void CTriangularPatchView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_eManipulationMode = Trackball;
	m_ptPrev = point;

	GLPtTo3DVec(point, m_vPrevVec);
	m_bIsTracking = true;
	SetCapture();
	
	CView::OnLButtonDown(nFlags, point);
	
}

/////////////////////////////////////////////////////////////////////////////
// Handlers: OnLButtonUp
void CTriangularPatchView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_eManipulationMode = None;
	m_bIsTracking = false;
	ReleaseCapture();

	CView::OnLButtonUp(nFlags, point);
	CClientDC* dc = new CClientDC(this); 
	OnDraw(dc);
	delete dc;
}

/////////////////////////////////////////////////////////////////////////////
// Handlers: OnMouseMove
void CTriangularPatchView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if (!nFlags)
		return;

	if (nFlags == MK_LBUTTON)
	{
		if (m_eManipulationMode == Trackball)
		{
			GLPtTo3DVec(point, m_vCurVec);

			GLfloat dx, dy, dz;
			dx = m_vCurVec[0] - m_vPrevVec[0];
			dy = m_vCurVec[1] - m_vPrevVec[1];
			dz = m_vCurVec[2] - m_vPrevVec[2];

			m_fTrackingAngle = 130.0f * (float) sqrt(dx*dx + dy*dy + dz*dz);
			
			m_vAxis[0] = m_vPrevVec[1]*m_vCurVec[2] - m_vPrevVec[2]*m_vCurVec[1];
			m_vAxis[1] = m_vPrevVec[2]*m_vCurVec[0] - m_vPrevVec[0]*m_vCurVec[2];
			m_vAxis[2] = m_vPrevVec[0]*m_vCurVec[1] - m_vPrevVec[1]*m_vCurVec[0];
			
			m_vPrevVec[0] = m_vCurVec[0];
			m_vPrevVec[1] = m_vCurVec[1];
			m_vPrevVec[2] = m_vCurVec[2];
		}

		Invalidate(FALSE);
		return;
	}
	else if (nFlags == MK_RBUTTON)
	{
		if(m_eManipulationMode == Panning)
		{
			m_fPanOffsetX += (float)(m_ptPrev.x - point.x) * m_fZoomScale / m_vViewport[3] * 2;
			m_fPanOffsetY -= (float)(m_ptPrev.y - point.y) * m_fZoomScale / m_vViewport[3] * 2;
			m_ptPrev = point;
		}

		Invalidate(FALSE);
		return;
	}

	CView::OnMouseMove(nFlags, point);
	
}

BOOL CTriangularPatchView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default
	m_eManipulationMode = Zooming;	
	m_fZoomScale *= 1.f + (float)((zDelta/1.0)/m_vViewport[2]);
	
	Invalidate(FALSE);
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}

/////////////////////////////////////////////////////////////////////////////
// Handlers: OnRButtonDown
void CTriangularPatchView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default]
	m_eManipulationMode = Panning;
	m_ptPrev = point;

	GLPtTo3DVec(point, m_vPrevVec);
	m_bIsTracking = true;
	SetCapture();

	CView::OnRButtonDown(nFlags, point);

}

/////////////////////////////////////////////////////////////////////////////
// Handlers: OnRButtonUp
void CTriangularPatchView::OnRButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_eManipulationMode = None;
	m_bIsTracking = false;
	ReleaseCapture();

	CView::OnRButtonUp(nFlags, point);
	CClientDC* dc = new CClientDC(this); 
	OnDraw(dc);
	delete dc;
	
}

/////////////////////////////////////////////////////////////////////////////
// Handlers: OnKeyDown
void CTriangularPatchView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	CTriangularPatchDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	switch(nChar)
	{
		case VK_LEFT:
			break;

		default:
			break;
	}
	
	CClientDC* dc = new CClientDC(this); 
	OnDraw(dc);
	delete dc;
	
	CView::OnKeyDown(nChar, nRepCnt, nFlags);

}

/////////////////////////////////////////////////////////////////////////////
// transform point to vector
void CTriangularPatchView::GLPtTo3DVec(CPoint point, GLfloat *pVec)
{
	// TODO: transform point to vector
	float dis, a;
	
	// project x,y onto semi-sphere centered within width, height
	pVec[0] = (2.0f*point.x - m_vViewport[2]) / m_vViewport[2];
	pVec[1] = (m_vViewport[3] - 2.0f*point.y) / m_vViewport[3];
	dis = (float) sqrt(pVec[0]*pVec[0] + pVec[1]*pVec[1]);
	pVec[2] = (float) cos((PI/2.0f) * ((dis < 1.0f) ? dis : 1.0f));
	a = (float) sqrt(pVec[0]*pVec[0] + pVec[1]*pVec[1] + pVec[2]*pVec[2]);
	pVec[0] /= a;
	pVec[1] /= a;
	pVec[2] /= a;
}

/////////////////////////////////////////////////////////////////////////////
// setup the projection matrix
void CTriangularPatchView::GLSetupFrustum(void)
{
	// TODO: setup the projection matrix
	double aspectRatio = (double)m_vViewport[3] / (double)m_vViewport[2];
	float nearPlane = m_fNearFactor * m_fViewingDistance;
	float farPlane = m_fFarFactor * m_fViewingDistance;
	
	float left = -(float)(m_fZoomScale / aspectRatio) + m_fPanOffsetX;
	float right = (float)(m_fZoomScale / aspectRatio) + m_fPanOffsetX;
	float bottom = -m_fZoomScale + m_fPanOffsetY;
	float top = m_fZoomScale + m_fPanOffsetY;
	
	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	glFrustum(left, right, bottom, top, nearPlane, farPlane);
	
	return;
}

/////////////////////////////////////////////////////////////////////////////
// setup the view transform matrix
void CTriangularPatchView::GLSetupTransform(void)
{
	// TODO: setup the view transform matrix
	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -m_fViewingDistance);
	if (m_eManipulationMode == Trackball && m_bIsTracking == true)
	{
		glPushMatrix();
		glLoadIdentity();
		glRotatef(m_fTrackingAngle, m_vAxis[0], m_vAxis[1], m_vAxis[2]);
		glMultMatrixf((GLfloat *)m_mxTransform);
		glGetFloatv(GL_MODELVIEW_MATRIX, (GLfloat *)m_mxTransform);
		glPopMatrix();
	}
	glMultMatrixf((GLfloat *)m_mxTransform);
}


/////////////////////////////////////////////////////////////////////////////
// Render your OpenGL Scene here.
void CTriangularPatchView::GLRenderScene(void *pData)
{
	CTriangularPatchDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	// Clear the window and the depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//GLDrawGradientBackground();
	
	// Set OpenLG view Parameters 
	GLSetupFrustum();
	GLSetupTransform();
	
	// Save matrix state and do the rotation
	glPushMatrix();
	
	// set material
	GLfloat ambient[4] = {0.3f, 0.3f, 0.3f, 0.5f};
	GLfloat material_ambient[4] = {0.0f, 0.0f, 0.0f, 0.0f};
	GLfloat material_diffuse[4] = {1.0f, 1.0f, 1.0f, 0.3f};
	GLfloat material_specular[4] = {0.5f, 0.5f, 0.5f, 0.5f};
	GLfloat material_shininess = 51.2f;
	
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, material_specular);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, material_diffuse);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, material_ambient);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, material_shininess);
	
	// draw scenes
	glutSolidTorus(1.0, 5.0, 100, 50);
	
	// Restore transformations
	glPopMatrix();
	
	// Flush drawing commands
	glFlush();

}

BOOL CTriangularPatchView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	
	return FALSE;	
//	return CView::OnEraseBkgnd(pDC);
}

